package main;

import main.model.cells.CellCreator;
import main.model.sheets.Sheet;
import main.model.sheets.SortSheet;

public class ScriptedDemo {
    public static void run() {
        System.out.println("This is a scripted demo. It will run a series of commands to demonstrate the functionality of the spreadsheet.");

        // Initialize the spreadsheet
        System.out.println("Initializing the spreadsheet...");
        SortSheet sheet = new SortSheet(10, 10);  // Initialize a 10x10 sheet with sorting capabilities
        CellCreator cellCreator = new CellCreator(sheet); // Creates cells for the sheet based on the input

        // Set some initial values
        sheet.setCell("A1", cellCreator.createCell("5"));
        sheet.setCell("A2", cellCreator.createCell("3"));
        sheet.setCell("A3", cellCreator.createCell("7"));
        sheet.setCell("A4", cellCreator.createCell("=1+1"));

        // Print the initial state of the sheet
        System.out.println("\nInitial state of the sheet:");
        sheet.print();

        // Set a text cell and a formula cell
        sheet.setCell("B1", cellCreator.createCell("Let A1 + A2:"));
        sheet.setCell("B2", cellCreator.createCell("=A1+A2"));
        sheet.recalculate(); // Recalculate the sheet after each command

        // Print the sheet after adding the text and formula cells
        System.out.println("\nSheet after adding text and formula cells:");
        sheet.print();

        // Combine recursive formula cells
        sheet.setCell("C1", cellCreator.createCell("Let B2^A4+A3:"));
        sheet.setCell("C2", cellCreator.createCell("=B2^A4+A3"));
        sheet.recalculate(); // Recalculate the sheet after each command

        // Print the sheet after adding the recursive formula cells
        System.out.println("\nSheet after adding recursive formula cells:");
        sheet.print();

        // Sort the sheet based on column A in ascending order
        sheet.sortColumn(0, true);
        sheet.recalculate(); // Recalculate the sheet after each command

        // Print the sheet after sorting
        System.out.println("\nSheet after sorting column A in ascending order:");
        sheet.print();

        // Sort the sheet based on column A in descending order
        sheet.sortColumn(0, false);
        sheet.recalculate(); // Recalculate the sheet after each command

        // Print the sheet after sorting
        System.out.println("\nSheet after sorting column A in descending order:");
        sheet.print();

        // And another recursive formula cells
        sheet.setCell("D1", cellCreator.createCell("Let (C2+A4*B2)+A3:"));
        sheet.setCell("D2", cellCreator.createCell("=(C2+A4*B2)+A3"));
        sheet.setCell("D3", cellCreator.createCell("Let D2/4:"));
        sheet.setCell("D4", cellCreator.createCell("=D2/4"));
        sheet.recalculate(); // Recalculate the sheet after each command

        // Print the sheet after adding the recursive formula cells
        System.out.println("\nSheet after adding more recursive formula cells:");
        sheet.print();
    }
}
