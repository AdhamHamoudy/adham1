package main;

public class Main {
    public static void main(String[] args) {
        // Scripted Demo
        ScriptedDemo.run();

        // Interactive Demo
   //   Demo.run();
    }
}