package main;

import main.model.cells.Cell;
import main.model.cells.CellCreator;
import main.model.sheets.SortSheet;

import java.util.Scanner;

public class Demo {
    private static SortSheet sheet;
    private static CellCreator cellCreator;
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        run();
    }

    public static void run() {
        System.out.println("Initializing the spreadsheet...");
        initSheet(10, 10);  // Initialize a 10x10 sheet

        boolean running = true;
        while (running) {
            System.out.println("\nAvailable Commands: SET <cell> <value>, GET <cell>, PRINT, SORT <column> [asc|desc], EXIT");
            System.out.print("Enter command: ");
            String command = scanner.nextLine();
            String[] parts = command.split("\\s+");

            try {
                switch (parts[0].toUpperCase()) {
                    case "SET":
                        handleSet(parts[1], parts[2]);
                        break;
                    case "GET":
                        handleGet(parts[1]);
                        break;
                    case "PRINT":
                        sheet.print();
                        break;
                    case "SORT":
                        if (parts.length < 3) {
                            System.out.println("Please specify the sort direction (asc or desc) after the column number.");
                        } else {
                            handleSort(Integer.parseInt(parts[1]), parts[2]);
                        }
                        break;
                    case "EXIT":
                        running = false;
                        break;
                    default:
                        System.out.println("Unknown command. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

            // After each command, recalculate the sheet
            sheet.recalculate();
        }
    }

    private static void initSheet(int rows, int cols) {
        sheet = new SortSheet(rows, cols);
        cellCreator = new CellCreator(sheet);
    }

    private static void handleSet(String cellRef, String value) {
        Cell cell = cellCreator.createCell(value);
        sheet.setCell(cellRef, cell);
        System.out.println("Set " + cellRef + " to " + value);
    }

    private static void handleGet(String part) {
        Cell cell = sheet.getCell(part);
        System.out.println("Value at " + part + ": " + cell.getValue() + " (Type: " + cell.getType() + ")");
    }

    private static void handleSort(int column, String direction) {
        boolean ascending = "asc".equalsIgnoreCase(direction);
        try {
            sheet.sortColumn(column - 1, ascending);  // Convert 1-based to 0-based index, handle sort direction
            System.out.println("Sorted column " + column + " in " + (ascending ? "ascending" : "descending") + " order.");
        }
        catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
