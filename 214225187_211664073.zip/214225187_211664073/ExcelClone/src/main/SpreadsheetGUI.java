package main;

import main.model.cells.CellCreator;
import main.model.sheets.Sheet;
import main.model.sheets.SortSheet;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class SpreadsheetGUI extends JFrame {
    private JTable table;
    private JTable rowHeader;
    private JScrollPane scrollPane;
    private SortSheet sheet;
    final private CellCreator cellCreator;
    private boolean isUpdating = false;

    public SpreadsheetGUI(SortSheet sheet, CellCreator cellCreator) {
        this.sheet = sheet;
        this.cellCreator = cellCreator;
        setTitle("Excel Clone");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initUI();
    }

    private void initMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu helpMenu = new JMenu("Help");
        JMenuItem cellTypeInfo = new JMenuItem("Cell Type Info");
        cellTypeInfo.addActionListener(e -> showCellTypeInfoDialog());
        helpMenu.add(cellTypeInfo);

        menuBar.add(helpMenu);
        setJMenuBar(menuBar);
    }

    private void showCellTypeInfoDialog() {
        String infoText = "<html><body><p style='width: 200px;'>" +
                "<b>Cell types:</b><br>" +
                "You may create a number cell by inserting a decimal.<br>" +
                "You may create a formula cell by starting it with '='.<br>" +
                "'=1+1' will turn into number, but '=A1+1' will stay formula.<br>" +
                "Otherwise, it'll be a text cell.</p></body></html>";

        JOptionPane.showMessageDialog(this, infoText, "Cell Type Information", JOptionPane.INFORMATION_MESSAGE);
    }


    private void initUI() {
        String[] columnNames = getColumnNames();
        Object[][] data = initializeData();

        initMenuBar();

        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return true;  // or any other condition
            }
        };
        table = new JTable(model);
        table.setCellSelectionEnabled(true);

        // Add a TableModelListener to the model
        model.addTableModelListener(e -> {
            if (!isUpdating) {
                int row = e.getFirstRow();
                int column = e.getColumn();
                TableModel innerModel = (TableModel) e.getSource();
                Object innerData = innerModel.getValueAt(row, column);
                handleCellChange(row, column, innerData);
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setRowHeaderView(rowHeader);
        add(scrollPane);

        JToolBar toolBar = new JToolBar();
        JButton sortButton = new JButton("Sort Column");
        sortButton.addActionListener(e -> showSortDialog());
        toolBar.add(sortButton);

        getContentPane().add(toolBar, BorderLayout.NORTH);
    }

    private void handleCellChange(int row, int column, Object data) {
        if (isUpdating) return;  // Prevent recursion if already updating

        try {
            isUpdating = true;  // Set flag to indicate updating is in progress
            sheet.setCell(row, column, cellCreator.createCell(data.toString())); // Update model
            sheet.recalculate(); // Recalculate sheet

            // Update GUI with the recalculated value
            refreshTable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error processing data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            sheet.setCell(row, column, cellCreator.createCell(""));  // Reset cell to empty value
            refreshTable();
        } finally {
            isUpdating = false;  // Reset flag after updating
        }
    }

    private void refreshTable() {
        for (int i = 0; i < sheet.getRows(); i++) {
            for (int j = 0; j < sheet.getCols(); j++) {
                table.getModel().setValueAt(sheet.getCell(i, j).getValue(), i, j);
            }
        }
    }

    private void showSortDialog() {
        // Create and display a dialog to choose column and sort order
        JDialog sortDialog = new JDialog(this, "Sort Options", true);
        sortDialog.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        JComboBox<String> columnSelect = new JComboBox<>(getColumnNames());
        JRadioButton ascButton = new JRadioButton("Ascending", true);
        JRadioButton descButton = new JRadioButton("Descending");
        ButtonGroup orderGroup = new ButtonGroup();
        orderGroup.add(ascButton);
        orderGroup.add(descButton);

        panel.add(new JLabel("Select Column:"));
        panel.add(columnSelect);
        panel.add(new JLabel("Order:"));
        panel.add(ascButton);
        panel.add(descButton);

        JButton sortConfirm = new JButton("Sort");
        sortConfirm.addActionListener(e -> {
            sortColumn(columnSelect.getSelectedIndex(), ascButton.isSelected());
            sortDialog.dispose();
        });

        sortDialog.add(panel, BorderLayout.CENTER);
        sortDialog.add(sortConfirm, BorderLayout.SOUTH);

        sortDialog.pack();
        sortDialog.setLocationRelativeTo(this);
        sortDialog.setVisible(true);
    }

    private void sortColumn(int columnIndex, boolean ascending) {
        if (isUpdating) return; // Prevent recursion if already updating

        try {
            isUpdating = true;  // Indicate updating is in progress
            sheet.sortColumn(columnIndex, ascending);  // Sort the column in the Sheet
            sheet.recalculate();  // Recalculate the sheet
            refreshTable();  // Refresh GUI
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error sorting data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            isUpdating = false;  // Reset flag after updating
        }
    }


    private String[] getColumnNames() {
        int numCols = sheet.getCols();
        String[] names = new String[numCols];
        for (int i = 0; i < numCols; i++) {
            names[i] = Sheet.getColumnName(i + 1);  // Assuming getColumnName is a static method in Sheet
        }
        return names;
    }

    private Object[][] initializeData() {
        int numRows = sheet.getRows();
        int numCols = sheet.getCols();
        Object[][] data = new Object[numRows][numCols];
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                data[i][j] = sheet.getCell(i, j).getValue();
            }
        }
        return data;
    }

    public static void main(String[] args) {
        SortSheet sheet = new SortSheet(20, 15);
        SpreadsheetGUI frame = new SpreadsheetGUI(sheet, new CellCreator(sheet));
        frame.setVisible(true);
    }
}
