package main.model.cells;

/*
 * The Formula interface defines the required operations for handling mathematical expressions
 * in cells within a spreadsheet. Implementing this interface allows a cell to interpret and
 * compute expressions potentially involving references to other cells.
 */
public interface Formula {

    /*
     * Parses the given mathematical expression, preparing it for evaluation. This method should
     * handle the conversion of cell references within the expression to their current values,
     * ensuring the expression is ready for direct calculation.
     * 'expression' The raw mathematical expression to be parsed.
     */
    void parse(String expression);

    /*
     * Calculates and returns the numerical result of the parsed expression. This method assumes
     * that the expression has been fully prepared (parsed) and is ready for computation.
     * return The calculated result of the expression as a double.
     */
    double calculate();
}
