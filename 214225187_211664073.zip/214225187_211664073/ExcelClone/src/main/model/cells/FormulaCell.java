package main.model.cells;

import main.model.ExpressionCalculator;
import main.model.sheets.Sheet;


public class FormulaCell extends AbstractCell implements Formula {
    private String parsedExpression;
    final private Sheet sheet; // Reference to the sheet to access other cells
    final private ExpressionCalculator expressionCalculator; // Helper class to evaluate expressions (string -> double)

    /*
     * Constructor for initializing a FormulaCell with a reference to its parent sheet.
     * sheet The Sheet instance that this cell is part of, used to access other cells.
     */
    public FormulaCell(Sheet sheet) {
        this.sheet = sheet;
        this.expressionCalculator = new ExpressionCalculator();
    }

    /*
     * Constructor for initializing a FormulaCell with both a parent sheet and an initial formula.
     * Immediately evaluates the formula upon creation.
     * sheet The Sheet instance that this cell is part of.
     * value The initial formula to be evaluated and stored in this cell.
     */
    public FormulaCell(Sheet sheet, String value) {
        this.sheet = sheet;
        this.value = value;
        this.expressionCalculator = new ExpressionCalculator();
        evaluate();
    }

    /*
     * Evaluates the cell's formula by parsing the initial expression and then calculating its value.
     * This process updates the `evaluatedValue` with the result of the formula based on current cell data.
     */
    @Override
    public void evaluate() {
        parse(value);
        evaluatedValue = String.valueOf(calculate());
    }

    /*
     * Returns the type of cell as a string.
     * return "Formula", indicating this cell stores numerical data.
     */
    @Override
    public String getType() {
        return "Formula";
    }

    /*
     * Parses the formula stored in `value` to replace spreadsheet cell references with their current values,
     * preparing it for calculation. This transformed expression is stored in `parsedExpression`.
     */
    @Override
    public void parse(String expression) {
        this.parsedExpression = convertCellReference(expression);
    }

    /*
     * Calculates the numerical result of the parsed expression using an  ExpressionCalculator.
     * return The result of the expression as a double.
     */
    @Override
    public double calculate() {
        return expressionCalculator.calculate(parsedExpression);
    }

    /*
     * Converts cell references in a formula to their respective evaluated values.
     * E.g., if A1 contains 6 and A2 contains 1, "A1+A2" becomes "(6)+(1)". // A3 := A1+A2
     * Numbers and non-cell references are not mistaken for cell references.
     * 'expression' The formula containing cell references and numbers.
     * return The formula with cell references replaced by their current values.
     */
    public String convertCellReference(String expression) {
        StringBuilder convertedExpression = new StringBuilder();
        StringBuilder cellReference = new StringBuilder();
        boolean isBuildingReference = false;

        for (char ch : expression.toCharArray()) {
            if (Character.isLetter(ch) && !isBuildingReference) {
                // Potentially starting a new reference
                if (cellReference.length() > 0 && !isCellReference(cellReference.toString())) {
                    // Previous buffer is not a reference, flush as literal text
                    convertedExpression.append(cellReference);
                    cellReference.setLength(0);
                }
                cellReference.append(ch);
                isBuildingReference = true; // Start building a potential cell reference
            } else if (Character.isDigit(ch) && isBuildingReference) {
                cellReference.append(ch);
            } else {
                // If the character is not a letter or digit, or it is a letter following digits
                if (isBuildingReference && !isCellReference(cellReference.toString())) {
                    // If building a reference but it's not valid
                    throw new IllegalArgumentException("Invalid expression component: " + cellReference);
                }
                flushNumberOrReference(convertedExpression, cellReference.toString(), isBuildingReference);
                cellReference.setLength(0);
                convertedExpression.append(ch);
                isBuildingReference = false;
            }
        }

        // Flush the last gathered tokens if any
        if (cellReference.length() > 0) {
            flushNumberOrReference(convertedExpression, cellReference.toString(), isBuildingReference);
        }

        return convertedExpression.toString();
    }

    /*
     * Processes and appends a token to the converted expression. If the token is a valid cell reference
     * and flagged as such, it retrieves and appends the evaluated cell value enclosed in parentheses.
     * If the token is not a cell reference or the flag is false, it appends the token directly.
     *  'convertedExpression' The StringBuilder to which the converted or original token is appended.
     *  'token'    The current token being processed, which may be a number or a potential cell reference.
     *  'isReference' A boolean indicating whether the current token is potentially a cell reference.
     */
    private void flushNumberOrReference(StringBuilder convertedExpression, String token, boolean isReference) {
        if (token.isEmpty()) return;  // If the token is empty, do nothing.

        if (isReference && isCellReference(token)) {
            // If the token is marked as a reference and matches the cell reference pattern,
            // get its evaluated value from the sheet.
            String evaluatedValue = getCellValue(token);
            // Append the evaluated value enclosed in parentheses to maintain clarity in the expression.
            convertedExpression.append("(").append(evaluatedValue).append(")");
        } else {
            // If it's not a valid reference or not intended as one, append the token as it is.
            convertedExpression.append(token);
        }
    }

    /*
     * Checks if a given string is a valid cell reference in a spreadsheet.
     * A valid cell reference is expected to start with one or more letters followed by one or more numbers.
     * For example, "A1", "C20", and "AA10" are valid references.
     * 'reference' The string to check.
     * return true if the string is a valid cell reference, false otherwise.
     */
    private boolean isCellReference(String reference) {
        return reference.matches("[A-Za-z]+\\d+$");
    }

    /*
     * Retrieves the evaluated value of a cell specified by its reference.
     * If the cell contains a formula, it ensures the formula is evaluated before returning the value.
     * Exceptions are thrown if the cell reference is invalid, out of bounds, or the cell is uninitialized.
     * 'cellReference' The reference to the cell (e.g., "A1").
     * return The evaluated value of the cell as a string.
     * throws RuntimeException if there is an issue accessing the cell, encapsulating the underlying exceptions.
     */
    private String getCellValue(String cellReference) {
        try {
            Cell cell = sheet.getCell(cellReference);
            if (cell instanceof FormulaCell) {
                cell.evaluate(); // Ensure formulas are evaluated
            }

            if (cell instanceof TextCell) {
                throw new IllegalArgumentException("Cannot reference a text cell: " + cellReference);
            }

            return cell.getValue();
        } catch (IllegalArgumentException | ArrayIndexOutOfBoundsException | NullPointerException e) {
            throw new RuntimeException("Error retrieving cell value for: " + cellReference, e);
        }
    }
}
