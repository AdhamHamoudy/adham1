package main.model.cells;


// * Represents a text cell in a spreadsheet, where the content is treated purely as text.

public class TextCell extends AbstractCell {

    /*
     * Constructs a new TextCell with the specified initial text value.
     * Immediately evaluates the text value, which in the case of TextCell,
     * means simply storing the original value as the evaluated value.
     * 'value' the text to be stored in the cell
     */
    public TextCell(String value) {
        super();
        this.value = value;
        evaluate();
    }

    /*
     * Evaluates the cell, assigning the input value directly to evaluatedValue.
     * For TextCell, evaluation does not modify the value.
     */
    @Override
    public void evaluate() {
        evaluatedValue = value;  // Direct assignment without modification.
    }

    /*
     * Returns the type of cell as a string.
     * return "Text", indicating this cell stores text data.
     */
    @Override
    public String getType() {
        return "Text";
    }
}
