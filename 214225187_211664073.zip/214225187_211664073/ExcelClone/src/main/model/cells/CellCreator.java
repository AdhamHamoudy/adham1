package main.model.cells;

import main.model.ExpressionCalculator;
import main.model.sheets.Sheet;

/*
 * CellCreator is responsible for creating different types of Cell objects based on the input value.
 * This factory method pattern simplifies cell creation and encapsulates the logic for determining
 * the type of cell to create, based on the string value provided.
 */
public class CellCreator {
    private final Sheet sheet;
    private final ExpressionCalculator expressionCalculator;

    public CellCreator(Sheet sheet) {
        this.sheet = sheet;
        this.expressionCalculator = new ExpressionCalculator();
    }

    /*
     * Creates a Cell object based on the input value format. Determines the type of Cell to create
     * by examining the value's format:
     * - Numbers are created as NumberCell.
     * - Strings starting with '=' are treated as formulas and created as FormulaCell.
     * - All other strings are created as TextCell.
     * 'value' The string value used to determine the type of Cell to create.
     * return Cell The newly created Cell object.
     * throws 'IllegalArgumentException' If the formula contains invalid characters or structures.
     */
    public Cell createCell(String value) throws IllegalArgumentException {
        if (value.matches("^-?\\d+(\\.\\d+)?$")) {
            return new NumberCell(value);
        } else if (value.startsWith("=")) {
            // Validate the formula to ensure it only contains valid characters and structures
            if (!isValidFormula(value.substring(1))) {
                System.out.println("Here1");
                throw new IllegalArgumentException("Invalid formula syntax: " + value);
            }

            // Check if value contains references to other cells (e.g., "=A1+B2")
            if (value.matches(".*[A-Z]\\d+.*")) {
                FormulaCell formulaCell = new FormulaCell(sheet, value.substring(1));

                // Evaluate the formula cell to calculate the result
                formulaCell.evaluate();
                System.out.println("Formula cell evaluated: " + formulaCell.getValue());
                return formulaCell;

            } else {
                // If the value is a simple calculation without references, calculate it
                try {
                    double calculated = expressionCalculator.calculate(value.substring(1));
                    return new NumberCell(String.valueOf(calculated));
                } catch (Exception e) {
                    System.out.println("Here2");
                    throw new IllegalArgumentException("Error calculating formula: " + value, e);
                }
            }
        } else {
            return new TextCell(value);
        }
    }

    /*
     * Validates if the formula only contains valid cell references, numbers, and operators.
     * 'formula' The formula to validate.
     * return true if the formula is valid, false otherwise.
     */
    private boolean isValidFormula(String formula) {
        String onlyValidChars = "^[A-Z0-9+\\-*/^r()]+$";

        // Then, check if the formula matches the pattern
        String correctOrder = "^(?!.*[A-Z](?![A-Z0-9]))[A-Z0-9+\\-*/^r()]+$";

        return formula.matches(onlyValidChars) && formula.matches(correctOrder);
    }
}
