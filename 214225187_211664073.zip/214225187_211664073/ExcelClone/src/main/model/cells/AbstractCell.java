package main.model.cells;


public abstract class AbstractCell implements Cell {
    protected String value;
    protected String evaluatedValue; // evaluate(value)

    @Override
    public String getValue() {
        return evaluatedValue;
    }

    @Override
    public void setValue(String value) {
        this.value = value;
        evaluate();
    }

    @Override
    public abstract void evaluate();
}
