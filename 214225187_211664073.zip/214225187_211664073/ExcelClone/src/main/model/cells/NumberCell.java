package main.model.cells;


// * Represents a numeric cell in a spreadsheet designed to handle and evaluate numerical data.

public class NumberCell extends AbstractCell {

    /*
     * Constructs a new NumberCell with the specified numeric value as a string.
     * The constructor attempts to parse and evaluate the string as a double.
     *  value the numeric value in string format to be stored and evaluated in the cell
     */
    public NumberCell(String value) {
        this.value = value;
        evaluate();
    }

    /*
     * Evaluates the numeric value, attempting to parse the string value to a double.
     * If the value cannot be parsed, the evaluated value is set to "Error".
     */
    @Override
    public void evaluate() {
        try {
            evaluatedValue = String.valueOf(Double.parseDouble(value));
        } catch (NumberFormatException e) {
            evaluatedValue = "Error";  // Error handling for non-parsable input.
        }
    }

    /*
     * Returns the type of cell as a string.
     * return "Numeric", indicating this cell stores numerical data.
     */
    @Override
    public String getType() {
        return "Numeric";
    }
}
