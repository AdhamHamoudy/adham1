package main.model.cells;

/*
 * Defines the contract for cell objects within a spreadsheet. Each cell in the spreadsheet
 * is responsible for managing its own content and behavior, including storing and updating
 * its value, evaluating any formulas it contains, and reporting its type.
 */
public interface Cell {

    /*
     * Sets the value of the cell. The value set can be a direct input, such as a number or text,
     * or a formula that needs to be evaluated.
     * 'value' The value or formula to be set in the cell.
     */
    void setValue(String value);

    /*
     * Retrieves the current value of the cell. If the cell contains a formula, this should return
     * the evaluated result of the formula, not the formula itself.
     * return The current value of the cell as a String.
     */
    String getValue();

    /*
     * Evaluates or re-evaluates the cell's content, especially if it contains a formula.
     * This method is used to update the cell's value based on the formula it contains and
     * any dependencies this cell might have on other cells. It should be called whenever
     * the cell or any of its dependencies change.
     */
    void evaluate();

    /*
     * Returns the type of the cell, which could indicate whether the cell contains plain text,
     * a numeric value, or a formula. This method helps identify the nature of the cell's content,
     * which can be crucial for rendering and processing the cell in the spreadsheet.
     * return A string representing the type of content in the cell, such as "Text", "Number", or "Formula".
     */
    String getType();
}
