package main.model.sheets;

/**
 * The ISpreadsheetOperations interface defines the fundamental operations for managing a spreadsheet, including
 * recalculating all formulas and printing the current state of the spreadsheet.
 */
public interface ISpreadsheetOperations {
    // Forces a recalculation of all cells in the sheet that contain formulas, ensuring all data is current.
    void recalculate();

    // Prints the current state of the spreadsheet to the console, showing all cell values in a structured format.
    void print();
}
