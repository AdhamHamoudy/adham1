package main.model.sheets;

import main.model.cells.Cell;
import main.model.cells.FormulaCell;
import main.model.cells.NumberCell;
import main.model.cells.TextCell;

/**
 * Represents a sheet that manages a grid of cells. This class supports fundamental sheet operations
 * such as setting and retrieving cells, recalculating formulas, and printing the sheet's content.
 * <p>
 * The Sheet is designed to work with different types of cells, including text, numeric, and formula cells,
 * enabling complex data management and computation typical in spreadsheet applications.
 */
public class Sheet implements ISpreadsheetOperations, ICellAccess {
    protected Cell[][] cells; // Grid of cells
    private final int rows;   // Number of rows in the sheet
    private final int cols;   // Number of columns in the sheet

    /**
     * Constructs a new Sheet with the specified number of rows and columns. This constructor initializes
     * each cell in the spreadsheet as an empty TextCell, setting up a ready-to-use blank sheet.
     *
     * @param rows the number of rows in the spreadsheet
     * @param cols the number of columns in the spreadsheet
     * @throws IllegalArgumentException if the number of rows or columns is less than or equal to zero
     */
    public Sheet(int rows, int cols) {
        if (rows <= 0 || cols <= 0) {
            throw new IllegalArgumentException("Invalid dimensions for the sheet");
        }

        this.rows = rows;
        this.cols = cols;
        cells = new Cell[rows][cols];
        initializeCells();
    }

    // Helper method to initialize all cells as text cells with empty values
    private void initializeCells() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                cells[i][j] = new TextCell(""); // Initialize as text cells
                cells[i][j].setValue(""); // Set initial empty value
            }
        }
    }

    @Override
    public Cell getCell(int row, int column) {
        return cells[row][column];
    }

    @Override
    public void setCell(int row, int column, Cell cell) {
        if (cell == null) {
            throw new NullPointerException("Cell cannot be null");
        }

        // Set the cell to be number cell if it's a number, formula cell if it's starting with '=' and text cell otherwise
        if (cell.getValue().matches("^-?\\d+(\\.\\d+)?$")) {
            // Check if the value is only a number
            cells[row][column] = new NumberCell(cell.getValue());
        } else if (cell.getValue().startsWith("=")) {
            // Starting with '=' indicates a formula cell, so create a new FormulaCell without the first character
            cells[row][column] = new FormulaCell(this, cell.getValue().substring(1));
        } else {
            cells[row][column] = new TextCell(cell.getValue());
        }

        cells[row][column] = cell;
        recalculate();
    }

    /**
     * Converts a spreadsheet-style cell reference to zero-based row and column indices.
     *
     * @param cellReference A string representing the cell's position, such as "A1".
     * @return An int array where the first element is the row index and the second element is the column index.
     * @throws IllegalArgumentException if the cell reference is invalid or does not follow the expected format.
     */
    @Override
    public int[] convertReferenceToRowAndColumn(String cellReference) {
        if (!isValidCellReference(cellReference)) {
            throw new IllegalArgumentException("Invalid cell reference: " + cellReference);
        }

        // Split the reference into letters and numbers
        String columnPart = cellReference.replaceAll("[^A-Z]", "");
        String rowPart = cellReference.replaceAll("[^0-9]", "");

        // Convert column letters (A, B, ..., AA, AB, ...) to a zero-based column index
        int col = 0;
        for (int i = 0; i < columnPart.length(); i++) {
            col = col * 26 + (columnPart.charAt(i) - 'A' + 1);
        }
        col -= 1; // Convert from 1-based to 0-based index

        // Convert row part to a zero-based row index
        int row = Integer.parseInt(rowPart) - 1;

        // Check if the indices are within the bounds of the sheet
        if (col < 0 || col >= cols || row < 0 || row >= rows) {
            throw new ArrayIndexOutOfBoundsException("Cell reference out of bounds: " + cellReference);
        }

        return new int[]{row, col};
    }

    @Override
    public Cell getCell(String cellReference) {
        int[] indices = convertReferenceToRowAndColumn(cellReference);
        return cells[indices[0]][indices[1]];
    }

    // Helper method to check if a cell reference is valid
    private boolean isValidCellReference(String cellReference) {
        // Valid cell reference must start with one or more letters followed by one or more digits till an operator or end of string
        return cellReference.matches("[A-Z]+\\d+");
    }

    @Override
    public void setCell(String cellReference, Cell cell) {
        // Use getCell method to validate cell reference and get row and column indices
        getCell(cellReference);  // This ensures the reference is valid

        // Convert cell reference to row and column indices
        int[] indices = convertReferenceToRowAndColumn(cellReference);

        cells[indices[0]][indices[1]] = cell;  // Note: Ensure that cells array is properly initialized and accessible
    }

    @Override
    public void recalculate() {
        for (Cell[] cell : cells) {
            for (Cell value : cell) {
                value.evaluate();
            }
        }
    }

    // Helper method to get column name from column number
    public static String getColumnName(int columnNumber) {
        StringBuilder columnName = new StringBuilder();
        while (columnNumber > 0) {
            int remainder = (columnNumber - 1) % 26;
            columnName.insert(0, (char) ('A' + remainder));
            columnNumber = (columnNumber - 1) / 26;
        }
        return columnName.toString();
    }

    // Helper method to get the number of rows in the sheet
    public int getRows() {
        return rows;
    }

    // Helper method to get the number of columns in the sheet
    public int getCols() {
        return cols;
    }

    @Override
    public void print() {
        // Print column headers
        System.out.print("    "); // Leading spaces for row numbers
        for (int j = 0; j < cols; j++) {
            System.out.print(getColumnName(j + 1) + "   "); // Use the helper function to get column names
        }
        System.out.println(); // Newline after header row

        // Print cell values
        for (int i = 0; i < rows; i++) {
            System.out.print((i + 1) + " | "); // Print row number
            for (int j = 0; j < cols; j++) {
                System.out.print((cells[i][j] != null ? cells[i][j].getValue() : "") + " | "); // Print cell value with separators
            }
            System.out.println(); // Move to the next line after printing each row
        }
    }
}