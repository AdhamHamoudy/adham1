package main.model.sheets;

import main.model.cells.Cell;

import java.util.Arrays;
import java.util.Comparator;

/**
 * SortSheet extends the basic Sheet class to add functionality for sorting columns.
 */
public class SortSheet extends Sheet {

    /**
     * Constructor for SortSheet. Initializes the sheet with the specified number of rows and columns.
     *
     * @param rows The number of rows in the sheet.
     * @param cols The number of columns in the sheet.
     */
    public SortSheet(int rows, int cols) {
        super(rows, cols);
    }

    /**
     * Sorts a specified column either in ascending or descending order, ensuring that empty strings
     * are always sorted to appear at the end of the column.
     *
     * @param column The column index to sort.
     * @param ascending A boolean flag indicating whether to sort in ascending (true) or descending (false) order.
     */
    public void sortColumn(int column, boolean ascending) {
        if (column < 0 || column >= getCols()) {
            throw new IllegalArgumentException("Column index is out of range.");
        }

        Cell[] columnData = new Cell[getRows()];
        for (int i = 0; i < getRows(); i++) {
            columnData[i] = cells[i][column];
        }

        // Iterate through the column, if a cell is formula, avoid sorting
        for (Cell cell : columnData) {
            if (cell.getType().equals("Formula")) {
                throw new IllegalArgumentException("Cannot sort a column with formula cells.");
            }
        }

        Comparator<Cell> comparator = (c1, c2) -> {
            String val1 = c1.getValue();
            String val2 = c2.getValue();

            // Check if either value is an empty string
            if (val1.isEmpty() && val2.isEmpty()) return 0;  // Both are empty, consider them equal
            if (val1.isEmpty()) return 1;  // val1 is empty, it should be last
            if (val2.isEmpty()) return -1;  // val2 is empty, it should be last

            // If both c1 and c2 are numbers, compare them as numbers
            if (val1.matches("^-?\\d+(\\.\\d+)?$") && val2.matches("^-?\\d+(\\.\\d+)?$")) {
                double num1 = Double.parseDouble(val1);
                double num2 = Double.parseDouble(val2);
                return ascending ? Double.compare(num1, num2) : Double.compare(num2, num1);
            }

            // Normal comparison for non-empty strings
            int result = val1.compareTo(val2);
            return ascending ? result : -result;
        };

        Arrays.sort(columnData, comparator);

        for (int i = 0; i < getRows(); i++) {
            cells[i][column] = columnData[i];
        }
    }
}
