package main.model.sheets;

import main.model.cells.Cell;

/**
 * The ICellAccess interface defines the fundamental operations for accessing and modifying cells in a spreadsheet.
 * It includes methods for retrieving and setting cells by their row and column indices [0, 0], as well as by their
 * spreadsheet-style references ("A1"), and for converting between these two representations.
 */
public interface ICellAccess {
    // Retrieves a cell from the spreadsheet at the specified row and column indices.
    Cell getCell(int row, int column);

    // Places a cell into the spreadsheet at the specified row and column indices, replacing any existing cell.
    void setCell(int row, int column, Cell cell);

    // Retrieves a cell using its spreadsheet-style reference (e.g., "A1").
    Cell getCell(String cellReference);

    // Places a cell into the spreadsheet at the position specified by a spreadsheet-style reference, replacing any existing cell.
    void setCell(String cellReference, Cell cell);

    // Converts a spreadsheet-style cell reference into zero-based row and column indices.
    int[] convertReferenceToRowAndColumn(String cellReference);
}
