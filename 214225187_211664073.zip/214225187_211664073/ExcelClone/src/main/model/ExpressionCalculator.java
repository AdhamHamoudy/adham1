package main.model;

import java.util.*;

/*
 * The ExpressionCalculator class provides a method to evaluate mathematical expressions
 * as a string that include basic arithmetic (+, -, *, /), exponential (^), and root (r) operations.
 * It supports parentheses for controlling the order of operations.
 */
public class ExpressionCalculator {

    /*
     * Calculates the result of a mathematical expression given as a string.
     * 'expression' The mathematical expression in string format.
     * return The evaluated result of the expression as a double.
     * throws 'IllegalArgumentException' If the expression is invalid.
     */
    public double calculate(String expression) {
        // Convert minus signs to unary operators
        // split expressions according to operators + - * / ^ r
        expression = convertNegativesToUnary(expression);
        Queue<String> postfix = infixToPostfix(expression);
        return evaluatePostfix(postfix);
    }

    private String convertNegativesToUnary(String expression) {
        // Trim the expression to remove leading and trailing spaces
        expression = expression.trim();

        // Replace negative numbers at the start of the expression
        expression = expression.replaceAll("^-", "(0-1)*");

        // Replace negative numbers after an operator or an opening parenthesis
        expression = expression.replaceAll("([+\\-*/(])\\s*-", "$1(0-1)*");

        return expression;
    }

    /*
     * Converts an infix expression to a postfix expression using the shunting yard algorithm.
     * Handles operators including +, -, *, /, ^ for power, and r for root.
     * 'expression' The infix mathematical expression in string format.
     * return A Queue representing the expression in postfix notation.
     * throws 'IllegalArgumentException' If the expression contains invalid number formats.
     */
    private Queue<String> infixToPostfix(String expression) {
        Map<String, Integer> precedence = new HashMap<>();
        precedence.put("+", 1);
        precedence.put("-", 1);
        precedence.put("*", 2);
        precedence.put("/", 2);
        precedence.put("^", 3);
        precedence.put("r", 3);

        Map<String, Boolean> rightAssociative = new HashMap<>();
        rightAssociative.put("^", true);
        rightAssociative.put("r", true);

        Deque<String> stack = new ArrayDeque<>();
        Queue<String> output = new LinkedList<>();
        String numberBuffer = "";

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            if (Character.isDigit(c) || c == '.') {
                numberBuffer += c;  // Append to the number buffer
            } else {
                if (!numberBuffer.isEmpty()) {
                    if (!isNumeric(numberBuffer)) {
                        throw new IllegalArgumentException("Invalid number format: " + numberBuffer);
                    }
                    output.add(numberBuffer);
                    numberBuffer = "";
                }

                String operator = String.valueOf(c);

                if (c == '(') {
                    stack.push(operator);
                } else if (c == ')') {
                    while (!stack.isEmpty() && !stack.peek().equals("(")) {
                        output.add(stack.pop());
                    }
                    if (!stack.isEmpty()) stack.pop();  // Remove the '(' from the stack
                } else if (precedence.containsKey(operator)) {
                    while (!stack.isEmpty() && precedence.containsKey(stack.peek())
                            && ((rightAssociative.getOrDefault(operator, false) && precedence.get(operator) < precedence.get(stack.peek()))
                            || (!rightAssociative.getOrDefault(operator, false) && precedence.get(operator) <= precedence.get(stack.peek())))) {
                        output.add(stack.pop());
                    }
                    stack.push(operator);
                }
            }
        }

        if (!numberBuffer.isEmpty()) {
            if (!isNumeric(numberBuffer)) {
                throw new IllegalArgumentException("Invalid number format: " + numberBuffer);
            }
            output.add(numberBuffer);
        }

        while (!stack.isEmpty()) {
            output.add(stack.pop());
        }

        // If the output expression is empty, the input expression is invalid
        if (output.isEmpty()) {
            throw new IllegalArgumentException("Formula has no numbers or operators: " + expression);
        }

        // If the output expression contains only operators, the input expression is invalid
        if (output.stream().allMatch(op -> !isNumeric(op))) {
            throw new IllegalArgumentException("Invalid expression: Cannot consist solely of operators");
        }


        return output;
    }

    /*
     * Evaluates a postfix expression.
     * 'postfix' The postfix expression as a Queue of string tokens.
     * return The evaluated result as a double.
     */
    private double evaluatePostfix(Queue<String> postfix) {
        Deque<Double> stack = new ArrayDeque<>();

        while (!postfix.isEmpty()) {
            String token = postfix.poll();

            if (isNumeric(token)) {
                stack.push(Double.parseDouble(token));
            } else {
                double b = stack.pop();
                double a = stack.isEmpty() ? 0 : stack.pop();

                switch (token) {
                    case "+" -> stack.push(a + b);
                    case "-" -> stack.push(a - b);
                    case "*" -> stack.push(a * b);
                    case "/" -> stack.push(a / b);
                    case "^" -> stack.push(Math.pow(a, b));
                    case "r" -> stack.push(Math.pow(a, 1.0 / b));
                    default -> throw new IllegalArgumentException("Invalid operator: " + token);
                }
            }
        }

        return stack.pop();
    }

    /*
     * Checks if a string is a valid numeric format.
     * 'str' The string to check.
     * return True if the string is a valid numeric format, otherwise false.
     */
    private boolean isNumeric(String str) {
        if (str == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(str);
            return true;
        } catch (NumberFormatException nfe) {
            return false;
        }
    }
}
