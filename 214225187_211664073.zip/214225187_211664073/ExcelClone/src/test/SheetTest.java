package test;

import static org.junit.Assert.assertEquals;

import main.model.cells.CellCreator;
import main.model.sheets.Sheet;
import org.junit.Test;

public class SheetTest {
    final private Sheet sheet = new Sheet(60, 60);
    final private CellCreator cellCreator = new CellCreator(sheet);

    @Test
    public void setCellAndGetCell() {
        // Test getCell with reference
        sheet.setCell("A2", cellCreator.createCell("5"));
        sheet.setCell("B5", cellCreator.createCell("3"));
        assertEquals("5.0", sheet.getCell("A2").getValue());
        assertEquals("3.0", sheet.getCell("B5").getValue());

        // Test getCell with row and column
        sheet.setCell(0, 1, cellCreator.createCell("5"));
        sheet.setCell(4, 1, cellCreator.createCell("3"));
        assertEquals("5.0", sheet.getCell(1, 0).getValue());
        assertEquals("3.0", sheet.getCell(4, 1).getValue());
    }

    @Test
    public void convertReferenceToRowAndColumn() {
        int[] result = sheet.convertReferenceToRowAndColumn("A1");
        assertEquals(0, result[0]);
        assertEquals(0, result[1]);

        result = sheet.convertReferenceToRowAndColumn("B2");
        assertEquals(1, result[0]);
        assertEquals(1, result[1]);

        result = sheet.convertReferenceToRowAndColumn("C3");
        assertEquals(2, result[0]);
        assertEquals(2, result[1]);

        result = sheet.convertReferenceToRowAndColumn("D4");
        assertEquals(3, result[0]);
        assertEquals(3, result[1]);

        result = sheet.convertReferenceToRowAndColumn("E5");
        assertEquals(4, result[0]);
        assertEquals(4, result[1]);
    }

    @Test
    public void testConvertingWithMoreThanOneLetter() {
        int[] result = sheet.convertReferenceToRowAndColumn("AA1");
        assertEquals(0, result[0]);
        assertEquals(26, result[1]);

        result = sheet.convertReferenceToRowAndColumn("AB2");
        assertEquals(1, result[0]);
        assertEquals(27, result[1]);

        result = sheet.convertReferenceToRowAndColumn("AC3");
        assertEquals(2, result[0]);
        assertEquals(28, result[1]);

        result = sheet.convertReferenceToRowAndColumn("AD4");
        assertEquals(3, result[0]);
        assertEquals(29, result[1]);

        result = sheet.convertReferenceToRowAndColumn("AE5");
        assertEquals(4, result[0]);
        assertEquals(30, result[1]);
    }
}