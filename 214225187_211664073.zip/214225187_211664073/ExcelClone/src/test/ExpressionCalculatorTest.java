package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import main.model.ExpressionCalculator;
import org.junit.Before;
import org.junit.Test;

public class ExpressionCalculatorTest {
    private ExpressionCalculator calculator;

    @Before
    public void setUp() {
        calculator = new ExpressionCalculator();
    }

    @Test
    public void testSimpleExpression() {
        assertEquals("Expected result is 2", 2, calculator.calculate("2"), 0.001);
        assertEquals("Expected result is 4", 4, calculator.calculate("2+2"), 0.001);
        assertEquals("Expected result is 1", 1, calculator.calculate("3-2"), 0.001);
        assertEquals("Expected result is 6", 6, calculator.calculate("3*2"), 0.001);
        assertEquals("Expected result is 3", 3, calculator.calculate("6/2"), 0.001);
    }

    @Test
    public void testDoubleExpression() {
        assertEquals("Expected result is 4.6", 4.6, calculator.calculate("2.5+2.1"), 0.001);
    }

    @Test
    public void testNegativeExpression() {
        assertEquals("Expected result is -1", -1, calculator.calculate("2+-3"), 0.001);
        assertEquals("Expected result is -1", -1, calculator.calculate("-3+2"), 0.001);
        assertEquals("Expected result is 6", 6, calculator.calculate("-3*-2"), 0.001);
        assertEquals("Expected result is -6", -6, calculator.calculate("3*-2"), 0.001);
        assertEquals("Expected result is -1.5", -1.5, calculator.calculate("3/(-2)"), 0.001);
        assertEquals("Expected result is -1.5", -1.5, calculator.calculate("-3/2"), 0.001);
    }

    @Test
    public void testMultiOperations() {
        assertEquals("Expected result is 8", 8, calculator.calculate("2+2*3"), 0.001);
        assertEquals("Expected result is 8", 8, calculator.calculate("2*3+2"), 0.001);
        assertEquals("Expected result is 8", 8, calculator.calculate("(2+2)*2"), 0.001);
        assertEquals("Expected result is 9", 9, calculator.calculate("3^2"), 0.001);
        assertEquals("Expected result is 28", 28, calculator.calculate("3+5^2"), 0.001);
        assertEquals("Expected result is 4", 4, calculator.calculate("16r2"), 0.001);
    }

    @Test
    public void testBrackets() {
        assertEquals("Expected result is 8", 8, calculator.calculate("(8)"), 0.001);

        assertEquals("Expected result is 21", 21, calculator.calculate("3*(5+2)"), 0.001);
        assertEquals("Expected result is 17", 17, calculator.calculate("(3*5)+2"), 0.001);
        assertEquals("Expected result is 17", 17, calculator.calculate("(3*5)+2"), 0.001);

        // Brackets in brackets
        assertEquals("Expected result is 24", 24, calculator.calculate("3*(5+(2+1))"), 0.001);
        assertEquals("Expected result is 18", 18, calculator.calculate("3*((3+(2*1))+1)"), 0.001);
    }

    @Test
    public void testRoot() {
        assertEquals("Expected result is 4", 4, calculator.calculate("16r2"), 0.001);
        assertEquals("Expected result is 3", 3, calculator.calculate("27r3"), 0.001);
    }

    @Test
    public void testPower() {
        assertEquals("Expected result is 8", 8, calculator.calculate("2^3"), 0.001);
        assertEquals("Expected result is 16", 16, calculator.calculate("2^4"), 0.001);
    }

    @Test
    public void testInvalidExpressionThrowsException() {
        // Trailing Operator
        try {
            calculator.calculate("3+");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression", e.getMessage());
        }

        // Leading Operator
        try {
            calculator.calculate("+3");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression", e.getMessage());
        }

        // Only operator
        try {
            calculator.calculate("+");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression: Cannot consist solely of operators", e.getMessage());
        }

        // Only operators
        try {
            calculator.calculate("++");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression: Cannot consist solely of operators", e.getMessage());
        }

        // Mismatched Parentheses
        try {
            calculator.calculate("(3+5");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid operator: (", e.getMessage());
        }

        // Mismatched Parentheses
        try {
            calculator.calculate("3+5)");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression", e.getMessage());
        }

        // Invalid Characters
        try {
            calculator.calculate("3+5a");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression", e.getMessage());
        }

        // Invalid operator
        try {
            calculator.calculate("3&5");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression", e.getMessage());
        }

        // Consecutive Operators
        try {
            calculator.calculate("3++5");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression", e.getMessage());
        }

        // Division by Zero
        try {
            calculator.calculate("3/0");
        } catch (IllegalArgumentException e) {
            assertEquals("Division by zero", e.getMessage());
        }

        // Root of a Negative Number
        try {
            calculator.calculate("(-3)r2");
        } catch (IllegalArgumentException e) {
            assertEquals("Root of a negative number", e.getMessage());
        }

        // Invalid Number Format
        try {
            calculator.calculate("3.5.2");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid number format: 3.5.2", e.getMessage());
        }

        // String with no numbers (empty expression)
        try {
            calculator.calculate("");
        } catch (IllegalArgumentException e) {
            assertEquals("Formula has no numbers or operators: ", e.getMessage());
        }

        // String with no numbers (whitespace expression)
        try {
            calculator.calculate(" ");
        } catch (IllegalArgumentException e) {
            assertEquals("Formula has no numbers or operators: ", e.getMessage());
        }

        // String with no numbers (classic string expression)
        try {
            calculator.calculate("Hello World!");
        } catch (IllegalArgumentException e) {
            assertThrows(IllegalArgumentException.class, () -> {
                throw new IllegalArgumentException();
            });
        }

        // String with no numbers (random string expression)
        try {
            calculator.calculate("430it9ajj4q9-a9o-a4-013");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression", e.getMessage());
        }

        // Combine number and string
        try {
            calculator.calculate("3+a");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression", e.getMessage());
        }
    }
}