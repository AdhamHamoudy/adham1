package test;

import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import main.model.cells.*;
import main.model.sheets.Sheet;
import org.junit.Test;


public class CellCreatorTest {
    @Test
    public void testCreateNumberCell() {
        Sheet sheet = new Sheet(10, 10); // Assuming dimensions for the sheet
        CellCreator factory = new CellCreator(sheet);
        String value = "123.456";
        Cell cell = factory.createCell(value);
        assertTrue("Should create a NumberCell for numeric values", cell instanceof NumberCell);
    }

    @Test
    public void testCreateNumberCellNegative() {
        Sheet sheet = new Sheet(10, 10);
        CellCreator factory = new CellCreator(sheet);
        String value = "-123.456";
        Cell cell = factory.createCell(value);
        assertTrue("Should create a NumberCell for negative numeric values", cell instanceof NumberCell);
    }

    @Test
    public void testCreateFormulaCell() {
        Sheet sheet = new Sheet(10, 10);
        CellCreator factory = new CellCreator(sheet);
        String value = "=1+2";
        Cell cell = factory.createCell(value);
        assertTrue("Should create a FormulaCell for formula values", cell instanceof NumberCell);
    }

    @Test
    public void testCreateFormulaCellInvalid() {
        Sheet sheet = new Sheet(10, 10);
        CellCreator factory = new CellCreator(sheet);

        // Add a number to the sheet
        sheet.setCell("A1",factory.createCell("1"));

        // Create a formula cell with an invalid formula
        String value = "=1+A1";
        Cell cell = factory.createCell(value);
        assertTrue("Should create a FormulaCell for invalid formula values", cell instanceof FormulaCell);
    }

    @Test
    public void testCreateTextCell() {
        Sheet sheet = new Sheet(10, 10);
        CellCreator factory = new CellCreator(sheet);
        String value = "Hello World!";
        Cell cell = factory.createCell(value);
        assertTrue("Should create a TextCell for text values", cell instanceof TextCell);
    }

    @Test
    public void testThrows() {
        Sheet sheet = new Sheet(10, 10);
        CellCreator factory = new CellCreator(sheet);

        // Can't compute a text
        assertThrows(IllegalArgumentException.class, () -> {
            factory.createCell("=a+a");
        });

        // Can't compute a text to a number
        assertThrows(IllegalArgumentException.class, () -> {
            factory.createCell("=1+x");
        });


        // Can't add a number to a text even if the text relay on a reference
        sheet.setCell("A1", factory.createCell("1"));
        sheet.setCell("A2", factory.createCell("qqq"));
        assertThrows(java.lang.RuntimeException.class, () -> {
            factory.createCell("=A1+A2");
        });
    }
}