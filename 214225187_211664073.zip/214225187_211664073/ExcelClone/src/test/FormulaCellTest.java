package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import main.model.cells.CellCreator;
import main.model.cells.FormulaCell;
import main.model.sheets.Sheet;
import org.junit.Before;
import org.junit.Test;

public class FormulaCellTest {

    private Sheet sheet;
    private FormulaCell formulaCell;
    private CellCreator cellCreator;

    @Before
    public void setUp() {
        // Stub implementation of Sheet to be used for testing
        sheet = new Sheet(9, 9);
        // Create an instance of FormulaCell with the stubbed Sheet
        formulaCell = new FormulaCell(sheet);
        // Create an instance of CellCreator
        cellCreator = new CellCreator(sheet);
    }

    @Test
    public void testGetType() {
        // Test if the getType method returns the correct type
        assertEquals("Expected type is 'Formula'", "Formula", formulaCell.getType());
    }

    @Test
    public void testSetValue() {
        // Test if the setValue method sets the value correctly
        formulaCell.setValue("2+2");
        assertEquals("Expected value is '4.0'", "4.0", formulaCell.getValue());
    }

    @Test
    public void testSetValueThrows() {
        // Test if the setValue method throws an exception when the value is invalid
        try {
            formulaCell.setValue("2+");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid formula expression", e.getMessage());
        }

        // Test an empty value
        assertThrows(IllegalArgumentException.class, () -> formulaCell.setValue(""));

        // Test with " " value
        assertThrows(IllegalArgumentException.class, () -> formulaCell.setValue(" "));

    }

    @Test
    public void testConstructors() {
        // Test if the constructor sets the value and evaluates it
        formulaCell = new FormulaCell(sheet, "2+2");
        assertEquals("Expected value is '4.0'", "4.0", formulaCell.getValue());

        // Test if the constructor sets the value and evaluates it
        formulaCell = new FormulaCell(sheet, "2*3");
        assertEquals("Expected value is '6.0'", "6.0", formulaCell.getValue());
    }


    @Test
    public void testSetValueAndEvaluate() {
        // Set a value (formula expression) and evaluate
        formulaCell.setValue("2+2");
        formulaCell.evaluate();
        // Assert the evaluated value is as expected (return 4 from calculate method)
        assertEquals("Expected evaluated value is 4", "4.0", formulaCell.getValue());

        // Set a value (formula expression) and evaluate
        formulaCell.setValue("2*3");
        formulaCell.evaluate();
        // Assert the evaluated value is as expected (return 6 from calculate method)
        assertEquals("Expected evaluated value is 6", "6.0", formulaCell.getValue());

        // The calculation is implemented and tested in ExpressionCalculatorTest, here we just test the integration
    }

    @Test
    public void testConvertor() {
        // Test if the convertCellReference method returns the correct value
        sheet.setCell("A1", cellCreator.createCell("6"));
        assertEquals("Expected converted value is (6.0)", "(6.0)", formulaCell.convertCellReference("A1"));

        // 2 Parameters
        sheet.setCell("A1", cellCreator.createCell("2"));
        sheet.setCell("A2", cellCreator.createCell("3"));
        assertEquals("Expected converted value is (2.0)+(3.0)", "(2.0)+(3.0)", formulaCell.convertCellReference("A1+A2"));

        // 3 Parameters
        sheet.setCell("A3", cellCreator.createCell("5"));
        assertEquals("Expected converted value is (2.0)+(3.0)+(5.0)", "(2.0)+(3.0)+(5.0)", formulaCell.convertCellReference("A1+A2+A3"));
    }

    @Test
    public void testConvertorThrows() {
        // Test if the convertCellReference method throws an exception when the cell reference is invalid
        try {
            formulaCell.convertCellReference("A");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid cell reference", e.getMessage());
        }

        // Test an empty cell reference
        try {
            formulaCell.convertCellReference("");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid cell reference", e.getMessage());
        }
    }

    @Test
    public void testCalculateWithOtherCells() {
        // Set numbers
        sheet.setCell("A1", cellCreator.createCell("2"));
        sheet.setCell("A2", cellCreator.createCell("3"));

        // Assert type is Formula
        assertEquals("Expected type is 'Numeric'", "Numeric", sheet.getCell("A1").getType());

        // Set a value (formula expression) and evaluate
        formulaCell.setValue("A1+A2");
        formulaCell.evaluate();
        assertEquals("Expected evaluated value is 5", "5.0", formulaCell.getValue());

        // Set a value (formula expression) and evaluate
        sheet.setCell("A3", cellCreator.createCell("=A1+A2")); // A1 = 2, A2 = 3

        // Assert type is Formula
        assertEquals("Expected type is 'Formula'", "Formula", sheet.getCell("A3").getType());

        // Evaluate the formula cell
        sheet.getCell("A3").evaluate();
        assertEquals("Expected evaluated value is 5", "5.0", sheet.getCell("A3").getValue());

        // Set a new number
        sheet.setCell("A4", cellCreator.createCell("4"));
        // Set a value (formula expression) and evaluate
        sheet.setCell("A5", cellCreator.createCell("=A3+A4")); // A3 = A1+A2 = 5, A4 = 4

        // Assert type is Formula
        assertEquals("Expected type is 'Formula'", "Formula", sheet.getCell("A5").getType());

        // Evaluate the formula cell
        sheet.getCell("A5").evaluate();
        assertEquals("Expected evaluated value is 9", "9.0", sheet.getCell("A5").getValue());

        // Combine reference and number
        sheet.setCell("A6", cellCreator.createCell("=A5+1")); // A5 = 9
        // Evaluate the formula cell
        sheet.getCell("A6").evaluate();
        assertEquals("Expected evaluated value is 10", "10.0", sheet.getCell("A6").getValue());

        // The calculation is implemented and tested in ExpressionCalculatorTest, here we just test the integration
    }

    @Test
    public void testNumberAndThreshStringThrows() {
        // Test if the convertCellReference method throws an exception when the cell reference is invalid
        try {
            formulaCell.convertCellReference("=x+2");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression component: x", e.getMessage());
        }

        // Test an empty cell reference
        try {
            formulaCell.convertCellReference("=2+y");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid expression component: y", e.getMessage());
        }
    }

}
