package test;

import static org.junit.Assert.assertEquals;

import main.model.cells.CellCreator;
import main.model.sheets.SortSheet;
import org.junit.Test;

public class SortSheetTest {

    @Test
    public void testSortColumnPureStrings() {
        SortSheet sheet = new SortSheet(4, 4);
        CellCreator cellCreator = new CellCreator(sheet);

        sheet.setCell("A1", cellCreator.createCell("c"));
        sheet.setCell("A2", cellCreator.createCell("d"));
        sheet.setCell("A3", cellCreator.createCell("b"));
        sheet.setCell("A4", cellCreator.createCell("a"));

        sheet.print();

        // Sort the sheet by column 0
        sheet.sortColumn(0, true);

        // Print the sheet
        sheet.print();

        assertEquals("a", sheet.getCell("A1").getValue());
        assertEquals("b", sheet.getCell("A2").getValue());
        assertEquals("c", sheet.getCell("A3").getValue());
        assertEquals("d", sheet.getCell("A4").getValue());
    }

    @Test
    public void testSortColumnMixedStrings() {
        SortSheet sheet = new SortSheet(4, 4);
        CellCreator cellCreator = new CellCreator(sheet);

        sheet.setCell("A1", cellCreator.createCell("c"));
        sheet.setCell("A2", cellCreator.createCell("3"));
        sheet.setCell("A3", cellCreator.createCell("b"));
        sheet.setCell("A4", cellCreator.createCell("a"));

        sheet.print();

        // Sort the sheet by column 0
        sheet.sortColumn(0, true);

        // Print the sheet
        sheet.print();

        assertEquals("3.0", sheet.getCell("A1").getValue());
        assertEquals("a", sheet.getCell("A2").getValue());
        assertEquals("b", sheet.getCell("A3").getValue());
        assertEquals("c", sheet.getCell("A4").getValue());
    }

    @Test
    public void testSortColumnNumbers() {
        SortSheet sheet = new SortSheet(4, 4);
        CellCreator cellCreator = new CellCreator(sheet);

        sheet.setCell("A1", cellCreator.createCell("1"));
        sheet.setCell("A2", cellCreator.createCell("12"));
        sheet.setCell("A3", cellCreator.createCell("3"));
        sheet.setCell("A4", cellCreator.createCell("2"));

        sheet.print();

        // Sort the sheet by column 0
        sheet.sortColumn(0, true);

        // Print the sheet
        sheet.print();

        assertEquals("1.0", sheet.getCell("A1").getValue());
        assertEquals("2.0", sheet.getCell("A2").getValue());
        assertEquals("3.0", sheet.getCell("A3").getValue());
        assertEquals("12.0", sheet.getCell("A4").getValue());
    }

    @Test
    public void testSortColumnEmptyCells() {
        SortSheet sheet = new SortSheet(4, 4);
        CellCreator cellCreator = new CellCreator(sheet);

        sheet.setCell("A1", cellCreator.createCell("333"));
        sheet.setCell("A2", cellCreator.createCell(""));
        sheet.setCell("A3", cellCreator.createCell(""));
        sheet.setCell("A4", cellCreator.createCell("343"));

        sheet.print();

        // Sort the sheet by column 0
        sheet.sortColumn(0, true);

        // Print the sheet
        sheet.print();

        assertEquals("333.0", sheet.getCell("A1").getValue());
        assertEquals("343.0", sheet.getCell("A2").getValue());
        // Empty cells should be sorted to the end
        assertEquals("", sheet.getCell("A3").getValue());
        assertEquals("", sheet.getCell("A4").getValue());

        // Sort the sheet by column 0 in descending order
        sheet.sortColumn(0, false);
        assertEquals("343.0", sheet.getCell("A1").getValue());
        assertEquals("333.0", sheet.getCell("A2").getValue());
        // Empty cells should be sorted to the end
        assertEquals("", sheet.getCell("A3").getValue());
        assertEquals("", sheet.getCell("A4").getValue());
    }
}